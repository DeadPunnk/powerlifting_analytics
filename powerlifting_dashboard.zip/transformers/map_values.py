import pandas as pd 


if 'transformer' not in globals():
    from mage_ai.data_preparation.decorators import transformer
if 'test' not in globals():
    from mage_ai.data_preparation.decorators import test


body_part = {'Squat (Barbell)': 'Pernas',
    'Bench Press (Barbell)': 'Peitoral',
    'Deadlift (Barbell)': 'Costas',
    'Triceps Pushdown (Cable - Straight Bar)': 'Bracos',
    'Bent Over Row (Barbell)': 'Costas',
    'Leg Press': 'Pernas',
    'Overhead Press (Barbell)': 'Ombros',
    'Romanian Deadlift (Barbell)': 'Costas',
    'Lat Pulldown (Machine)': 'Costas',
    'Bench Press (Dumbbell)': 'Peitoral',
    'Skullcrusher (Dumbbell)': 'Bracos',
    'Lying Leg Curl (Machine)': 'Pernas',
    'Hammer Curl (Dumbbell)': 'Bracos',
    'Overhead Press (Dumbbell)': 'Ombros',
    'Lateral Raise (Dumbbell)': 'Ombros',
    'Chest Press (Machine)': 'Peitoral',
    'Incline Bench Press (Barbell)': 'Peitoral',
    'Hip Thrust (Barbell)': 'Pernas',
    'Agachamento Pausado ': 'Pernas',
    'Larsen Press': 'Peitoral',
    'Triceps Dip': 'Bracos',
    'Farmers March ': 'Abdomen',
    'Lat Pulldown (Cable)': 'Costas',
    'Face Pull (Cable)': 'Ombros',
    'Stiff Leg Deadlift (Barbell)': 'Pernas',
    'Bulgarian Split Squat': 'Pernas',
    'Front Squat (Barbell)': 'Pernas',
    'Incline Bench Press (Dumbbell)': 'Peitoral',
    'Reverse Fly (Dumbbell)': 'Ombros',
    'Push Press': 'Ombros',
    'Good Morning (Barbell)': 'Costas',
    'Leg Extension (Machine)': 'Pernas',
    'Standing Calf Raise (Smith Machine)': 'Pernas',
    'Skullcrusher (Barbell)': 'Bracos',
    'Strict Military Press (Barbell)': 'Ombros',
    'Seated Leg Curl (Machine)': 'Pernas',
    'Bench Press - Close Grip (Barbell)': 'Peitoral',
    'Hip Adductor (Machine)': 'Pernas',
    'Deficit Deadlift (Barbell)': 'Pernas',
    'Sumo Deadlift (Barbell)': 'Costas',
    'Box Squat (Barbell)': 'Pernas',
    'Seated Row (Cable)': 'Costas',
    'Bicep Curl (Dumbbell)': 'Bracos',
    'Spotto Press': 'Peitoral',
    'Incline Chest Fly (Dumbbell)': 'Peitoral',
    'Incline Row (Dumbbell)': 'Costas'}

@transformer
def transform(data, *args, **kwargs):
    

    strong_data = data[['Date', 'Workout Name', 'Exercise Name', 'Weight', 'Reps', 'Workout Duration']]

    strong_data['Body part'] = strong_data['Exercise Name'].map(body_part)

    return strong_data


@test
def test_output(output, *args) -> None:
    """
    Template code for testing the output of the block.
    """
    assert output is not None, 'The output is undefined'
