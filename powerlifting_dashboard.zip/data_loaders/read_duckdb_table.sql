-- Docs: https://docs.mage.ai/guides/sql-blocks

SELECT * FROM powerlifting
WHERE workout_name IN ('Treino 1', 'Treino 2', 'Treino 3');
